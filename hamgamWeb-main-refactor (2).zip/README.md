# 汉堡图集 Hamburger

> 业余无线电图片分享社区 | HAM圈表情包 | BD8CWG

这是对 `hamgamWeb-main` 的 Vue 重构升级版，专注于业余无线电、HAM圈的图片分享社区。

## 核心特性

- **业余无线电图片分享**：收录业余电台、无线电软件、无线电表情包、HAM圈趣图
- **HAM社区互动**：评论、emoji反应、通知中心
- **投稿审核流程**：用户投稿 → 管理员审核 → 发布到图库
- **SEO优化**：完整的搜索引擎优化，支持百度、Google、Bing等

## 技术栈

- 前端：Vue 3、Vite、Pinia、Vue Router、MDUI 2
- 后端：Supabase（Auth、Postgres、Storage、Edge Functions）
- 安全：RLS、私有投稿桶、前端仅使用 Publishable Key

## SEO 优化

本项目已进行全面的搜索引擎优化：

### 1. Meta 标签优化
- 完整的 title、description、keywords
- Open Graph 标签（Facebook、微信分享）
- Twitter Card 标签

### 2. 结构化数据
- WebSite Schema（网站信息）
- Organization Schema（组织信息）
- SearchAction（站内搜索）

### 3. 搜索引擎配置
- `robots.txt`：配置爬虫规则
- `sitemap.xml`：网站地图

### 4. 关键词覆盖

主要关键词：
- 业余无线电
- 业余电台
- 无线电软件
- 无线电表情包
- HAM / HAM圈
- BD8CWG
- 业余无线电爱好者
- 火腿圈

## 快速开始

### 安装依赖

```bash
npm install
```

### 开发模式

```bash
npm run dev
```

### 构建生产版本

```bash
npm run build
```

## 环境变量配置

创建 `.env.local` 文件：

```bash
# 站点信息
VITE_SITE_NAME=🍔Hamburger
VITE_SITE_TITLE=汉堡图集 Hamburger - 业余无线电图片分享社区
VITE_SITE_DESCRIPTION=汉堡图集 Hamburger 是一个专注于业余无线电、HAM圈的图片分享社区
VITE_SITE_KEYWORDS=业余无线电,业余电台,无线电软件,无线电表情包,HAM,HAM圈,BD8CWG
VITE_SITE_AUTHOR=BD8CWG
VITE_SITE_URL=https://hamburger.hamgam.cn

# Supabase 配置
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=

# 存储桶配置
VITE_PUBLIC_GALLERY_BUCKET=gallery-images
VITE_PRIVATE_SUBMISSION_BUCKET=submission-images

# 功能开关
VITE_ENABLE_SIGNUP=true
VITE_DEFAULT_REACTION_SET=❤️,👍,😂,😭,🔥,👀,😮,🤔,🥰,👏

# Cloudflare Turnstile 验证码
VITE_TURNSTILE_SITE_KEY=

# 高德地图（可选）
VITE_AMAP_JS_KEY=
VITE_AMAP_SECURITY_JS_CODE=
```

## 功能列表

### 用户功能
- 首页图墙（乱序/最近更新）
- 随机一张
- 图片详情与评论
- Emoji 反应
- 投稿上传
- 通知中心
- 呼号申请

### 管理功能
- 投稿审核
- 用户管理
- 公告管理
- 站内通知
- 审计日志

## 部署

### Supabase 初始化

1. 执行 `supabase/schema.sql` 创建数据库表
2. 创建首个超级管理员
3. 部署 Edge Function

### 前端部署

项目使用 Hash Router，可部署到任何静态托管服务。

## SEO 提交建议

1. **百度站长平台**
   - 提交网站：https://ziyuan.baidu.com
   - 提交 sitemap：`https://hamburger.hamgam.cn/sitemap.xml`

2. **Google Search Console**
   - 提交网站：https://search.google.com/search-console
   - 提交 sitemap

3. **Bing Webmaster Tools**
   - 提交网站：https://www.bing.com/webmasters

## 许可证

MIT License

## 作者

BD8CWG（汉堡）
