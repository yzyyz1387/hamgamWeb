import { createApp } from 'vue'
import 'mdui/mdui.css'
import 'mdui'
import './assets/styles.css'
import App from './App.vue'
import router from './router'
import { pinia } from './stores'

const app = createApp(App)
app.use(pinia)
app.use(router)
app.mount('#app')
